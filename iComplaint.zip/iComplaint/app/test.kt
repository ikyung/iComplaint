package com.codingstuff.instag

import android.Manifest
import android.R
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import java.util.*

class SetUpActivity : AppCompatActivity() {
    private var circleImageView: CircleImageView? = null
    private var mProfileName: EditText? = null
    private var mSaveBtn: Button? = null
    private var auth: FirebaseAuth? = null
    private var storageReference: StorageReference? = null
    private var firestore: FirebaseFirestore? = null
    private var Uid: String? = null
    private var mImageUri: Uri? = null
    private var progressBar: ProgressBar? = null
    private var isPhotoSelected = false
    protected override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_up)
        val setUpToolbar: androidx.appcompat.widget.Toolbar =
            findViewById<androidx.appcompat.widget.Toolbar>(R.id.setup_toolbar)
        setSupportActionBar(setUpToolbar)
        getSupportActionBar().setTitle("Profile")
        storageReference = FirebaseStorage.getInstance().getReference()
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        Uid = auth.getCurrentUser().getUid()
        progressBar = findViewById<ProgressBar>(R.id.progressBar)
        progressBar!!.visibility = View.INVISIBLE
        circleImageView = findViewById<CircleImageView>(R.id.circleImageView)
        mProfileName = findViewById<EditText>(R.id.profile_name)
        mSaveBtn = findViewById<Button>(R.id.save_btn)
        auth = FirebaseAuth.getInstance()
        firestore.collection("Users").document(Uid).get()
            .addOnCompleteListener(object : OnCompleteListener<DocumentSnapshot?>() {
                override fun onComplete(task: com.google.android.gms.tasks.Task<DocumentSnapshot>) {
                    if (task.isSuccessful()) {
                        if (task.getResult().exists()) {
                            val name: String = task.getResult().getString("name")
                            val imageUrl: String = task.getResult().getString("image")
                            mProfileName!!.setText(name)
                            mImageUri = Uri.parse(imageUrl)
                            Glide.with(this@SetUpActivity).load(imageUrl).into(circleImageView)
                        }
                    }
                }
            })
        mSaveBtn!!.setOnClickListener {
            progressBar!!.visibility = View.VISIBLE
            val name = mProfileName!!.text.toString()
            val imageRef: StorageReference =
                storageReference.child("Profile_pics").child("$Uid.jpg")
            if (isPhotoSelected) {
                if (!name.isEmpty() && mImageUri != null) {
                    imageRef.putFile(mImageUri).addOnCompleteListener(object :
                        OnCompleteListener<com.google.firebase.storage.UploadTask.TaskSnapshot?>() {
                        override fun onComplete(task: com.google.android.gms.tasks.Task<com.google.firebase.storage.UploadTask.TaskSnapshot>) {
                            if (task.isSuccessful()) {
                                imageRef.getDownloadUrl().addOnSuccessListener(object :
                                    OnSuccessListener<Uri?>() {
                                    override fun onSuccess(uri: Uri) {
                                        saveToFireStore(task, name, uri)
                                    }
                                })
                            } else {
                                progressBar!!.visibility = View.INVISIBLE
                                Toast.makeText(
                                    this@SetUpActivity,
                                    task.getException().message,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    })
                } else {
                    progressBar!!.visibility = View.INVISIBLE
                    Toast.makeText(
                        this@SetUpActivity,
                        "Please Select picture and write your name",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                saveToFireStore(null, name, mImageUri)
            }
        }
        circleImageView.setOnClickListener(View.OnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ContextCompat.checkSelfPermission(
                        this@SetUpActivity,
                        Manifest.permission.READ_EXTERNAL_STORAGE
                    ) != PackageManager.PERMISSION_GRANTED
                ) {
                    ActivityCompat.requestPermissions(
                        this@SetUpActivity,
                        arrayOf<String>(Manifest.permission.READ_EXTERNAL_STORAGE),
                        1
                    )
                } else {
                    activity()
                        .setGuidelines(Guidelines.ON)
                        .setAspectRatio(1, 1)
                        .start(this@SetUpActivity)
                }
            }
        })
    }

    private fun saveToFireStore(
        task: com.google.android.gms.tasks.Task<com.google.firebase.storage.UploadTask.TaskSnapshot>?,
        name: String,
        downloadUri: Uri?,
    ) {
        val map = HashMap<String, Any>()
        map.put("name", name)
        map.put("image", downloadUri.toString())
        firestore.collection("Users").document(Uid).set(map)
            .addOnCompleteListener(object : OnCompleteListener<Void?>() {
                override fun onComplete(task: com.google.android.gms.tasks.Task<Void>) {
                    if (task.isSuccessful()) {
                        progressBar!!.visibility = View.INVISIBLE
                        Toast.makeText(
                            this@SetUpActivity,
                            "Profile Settings Saved",
                            Toast.LENGTH_SHORT
                        ).show()
                        startActivity(Intent(this@SetUpActivity, MainActivity::class.java))
                        finish()
                    } else {
                        progressBar!!.visibility = View.INVISIBLE
                        Toast.makeText(
                            this@SetUpActivity,
                            task.getException().toString(),
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            })
    }

    protected override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            val result: ActivityResult = getActivityResult(data)
            if (resultCode == Activity.RESULT_OK) {
                mImageUri = result.getUri()
                circleImageView.setImageURI(mImageUri)
                isPhotoSelected = true
            } else if (resultCode == CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Toast.makeText(this, result.getError().getMessage(), Toast.LENGTH_SHORT).show()
            }
        }
    }
}