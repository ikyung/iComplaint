package com.example.icomplaint


import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.icomplaint.adapter.PostAdapter
import com.example.icomplaint.databinding.ActivityMainBinding
import com.example.icomplaint.model.Post
import com.example.icomplaint.model.Users
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var mainToolbar: Toolbar
    private lateinit var firestore: FirebaseFirestore
    private lateinit var mRecyclerView: RecyclerView
    private lateinit var fab: FloatingActionButton
    private lateinit var adapter: PostAdapter
    private lateinit var list: MutableList<Post>
    private lateinit var query: Query
    private var listenerRegistration: ListenerRegistration? = null
    private var usersList: MutableList<Users?>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        firebaseAuth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mRecyclerView = findViewById(R.id.recyclerView)
        mRecyclerView.setHasFixedSize(true)
        mRecyclerView.setLayoutManager(LinearLayoutManager(this@MainActivity))
        list = ArrayList()
        usersList = ArrayList()
        adapter = PostAdapter(this@MainActivity, list, usersList)
        mRecyclerView.adapter = adapter
        fab = findViewById(R.id.floatingActionButton)
        mainToolbar = findViewById(R.id.main_toolbar)
        setSupportActionBar(mainToolbar)
        supportActionBar?.title = "Feed"

        fab.setOnClickListener {
            startActivity(
                Intent(this@MainActivity, AddPostActivity::class.java)
            )
        }
        if (firebaseAuth.currentUser != null) {
            mRecyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    super.onScrolled(recyclerView, dx, dy)
                    val isBottom = !mRecyclerView.canScrollVertically(1)
                    if (isBottom) Toast.makeText(
                        this@MainActivity,
                        "Reached Bottom",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            })
            query = firestore.collection("Posts").orderBy("time", Query.Direction.DESCENDING)
            listenerRegistration = query.addSnapshotListener(
                this@MainActivity
            ) { value, error ->
                for (doc in value!!.documentChanges) {
                    if (doc.type == DocumentChange.Type.ADDED) {
                        val postId = doc.document.id
                        val post: Post = doc.document.toObject(Post::class.java).withId(postId)
                        val postUserId = doc.document.getString("user")
                        firestore.collection("Users").document(postUserId!!).get()
                            .addOnCompleteListener { task ->
                                if (task.isSuccessful) {
                                    val users: Users? = task.result.toObject(Users::class.java)
                                    usersList?.add(users)
                                    list.add(post)
                                    adapter.notifyDataSetChanged()
                                } else {
                                    Toast.makeText(
                                        this@MainActivity,
                                        task.exception!!.message,
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            }
                    } else {
                        adapter.notifyDataSetChanged()
                    }
                }
                listenerRegistration?.remove()
            }
        }
    }



    override fun onStart() {
        super.onStart()
        val currentUser = firebaseAuth.currentUser
        if(currentUser == null){
            val intent = Intent(this@MainActivity , SignInActivity::class.java)
            startActivity(intent)
            finish()
        }else{
            val currentUserId = firebaseAuth.currentUser!!.uid
            firestore.collection("Users").document(currentUserId).get().addOnCompleteListener { task->
                if (task.isSuccessful){
                    if(!task.result!!.exists()){
                        startActivity(Intent(this , SetUpActivity::class.java))
                        finish()
                    }
                }
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.profile_menu -> {
                startActivity(Intent(this@MainActivity, SetUpActivity::class.java))
            }
            R.id.sign_out_menu -> {
                firebaseAuth.signOut()
                startActivity(Intent(this@MainActivity, SignInActivity::class.java))
                finish()
            }
        }
        return true
    }
}
