package com.example.icomplaint.model


class Users {
    val image: String? = null
    val name: String? = null
}