package com.example.icomplaint

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.bumptech.glide.Glide
import com.canhub.cropper.CropImage
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageView
import com.canhub.cropper.options
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import de.hdodenhof.circleimageview.CircleImageView


class SetUpActivity : AppCompatActivity() {

    private lateinit var circleImageView: CircleImageView
    private lateinit var mProfileName: EditText
    private lateinit var mSaveBtn: Button
    private lateinit var auth: FirebaseAuth
    private lateinit var storageReference: StorageReference
    private lateinit var firestore: FirebaseFirestore
    private lateinit var Uid: String
    private var mImageUri: Uri? = null
    private lateinit var progressBar: ProgressBar
    private var isPhotoSelected = false



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_set_up)

        val setUpToolbar: Toolbar = findViewById(R.id.setup_toolbar)
        setSupportActionBar(setUpToolbar)
        supportActionBar?.title = "Profile"

        storageReference = FirebaseStorage.getInstance().reference
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        Uid = auth.currentUser?.uid.toString()

        progressBar = findViewById(R.id.progressBar)
        progressBar.visibility = View.INVISIBLE

        circleImageView = findViewById(R.id.circleImageView)
        mProfileName = findViewById(R.id.profile_name)
        mSaveBtn = findViewById(R.id.save_btn)

        auth = FirebaseAuth.getInstance()

        Uid.let {
            firestore.collection("Users").document(it).get().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    if (task.result?.exists() == true) {
                        val name: String = task.result.getString("name").toString()
                        val imageUrl: String = task.result.getString("image").toString()
                        mProfileName.setText(name)
                        mImageUri = Uri.parse(imageUrl)
                        Glide.with(this@SetUpActivity).load(imageUrl).into(circleImageView)
                    }
                }
            }
        }

        mSaveBtn.setOnClickListener {
            progressBar.visibility = View.VISIBLE
            val name: String = mProfileName.text.toString()
            val imageRef: StorageReference = storageReference.child("Profile_pics").child("$Uid.jpg")
            if (isPhotoSelected) {
                if (!name.isEmpty() && mImageUri != null) {
                    imageRef.putFile(mImageUri!!).addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            imageRef.downloadUrl
                                .addOnSuccessListener { uri ->
                                    saveToFireStore(name, uri)
                                }
                        } else {
                            progressBar.visibility = View.INVISIBLE
                            Toast.makeText(
                                this@SetUpActivity, task.exception?.message, Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    progressBar.visibility = View.INVISIBLE
                    Toast.makeText(
                        this@SetUpActivity, "Please enter your name and select a profile photo", Toast.LENGTH_SHORT).show()
                }
            } else {
                if (!name.isEmpty()){
                    saveToFireStore(name, mImageUri)
                }else{
                    progressBar.visibility = View.INVISIBLE
                    Toast.makeText(this@SetUpActivity, "Please enter your name", Toast.LENGTH_SHORT).show()
                }

            }
        }

        val getContent = registerForActivityResult(CropImageContract()) { uri: CropImageView.CropResult? ->
            // Do something with the obtained Uri
            mImageUri = uri?.uriContent
            circleImageView.setImageURI(mImageUri)
        }
        circleImageView.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (ContextCompat.checkSelfPermission(this@SetUpActivity, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(this@SetUpActivity, arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE), 1)
                } else {
                    getContent.launch(
                    options {
                        setGuidelines(CropImageView.Guidelines.ON)
                        setAspectRatio(1,1)
                    }.apply {
                        this@SetUpActivity
                    })

                }
            }
        }
    }


    private fun saveToFireStore(name: String, downloadUri: Uri?) {
        val map = HashMap<String, Any>()
        map["name"] = name
        map["image"] = downloadUri.toString()
        firestore.collection("Users").document(Uid).set(map)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    progressBar.visibility = View.INVISIBLE
                    Toast.makeText(
                        this@SetUpActivity,
                        "Profile Settings Saved",
                        Toast.LENGTH_SHORT
                    ).show()
                    startActivity(Intent(this@SetUpActivity, MainActivity::class.java))
                    finish()
                } else {
                    progressBar.visibility = View.INVISIBLE
                    Toast.makeText(
                        this@SetUpActivity,
                        task.exception.toString(),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            val result = CropImage.ActivityResult
            if (resultCode == Activity.RESULT_OK) {
                mImageUri = data?.data
                circleImageView.setImageURI(mImageUri)
                isPhotoSelected = true
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Toast.makeText(this, result.toString(), Toast.LENGTH_SHORT).show()
            }
        }
    }

}