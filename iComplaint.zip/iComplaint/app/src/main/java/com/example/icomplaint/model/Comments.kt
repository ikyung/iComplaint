package com.example.icomplaint.model


class Comments : CommentsId() {
    val comment: String? = null
    val user: String? = null
}