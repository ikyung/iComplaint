package com.example.icomplaint.adapter


import android.app.Activity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.icomplaint.R
import com.example.icomplaint.model.Comments
import com.example.icomplaint.model.Users
import de.hdodenhof.circleimageview.CircleImageView

class CommentsAdapter(
    private val context: Activity,
    commentsList: List<Comments>,
    usersList: List<Users?>?,
) :
    RecyclerView.Adapter<CommentsAdapter.CommentsViewHolder>() {
    private val usersList: List<Users?>
    private val commentsList: List<Comments>

    init {
        this.commentsList = commentsList
        this.usersList = usersList ?: emptyList()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CommentsViewHolder {
        val view: View = LayoutInflater.from(context).inflate(R.layout.each_comment, parent, false)
        return CommentsViewHolder(view)
    }

    override fun onBindViewHolder(holder: CommentsViewHolder, position: Int) {
        val comments: Comments = commentsList[position]
        holder.setmComment(comments.comment)
        val users: Users? = usersList[position]
        if (users != null) {
            holder.setmUserName(users.name)
            holder.setCircleImageView(users.image)
        }
    }

    override fun getItemCount(): Int {
        return commentsList.size
    }

    inner class CommentsViewHolder(var mView: View) : RecyclerView.ViewHolder(
        mView
    ) {
        var mComment: TextView? = null
        var mUserName: TextView? = null
        var circleImageView: CircleImageView? = null
        fun setmComment(comment: String?) {
            mComment = mView.findViewById(R.id.comment_tv)
            mComment?.text = comment
        }

        fun setmUserName(userName: String?) {
            mUserName = mView.findViewById(R.id.comment_user)
            mUserName?.text = userName
        }

        fun setCircleImageView(profilePic: String?) {
            circleImageView = mView.findViewById(R.id.comment_Profile_pic) as CircleImageView
            Glide.with(context).load(profilePic).into(circleImageView!!)
        }
    }
}
