package com.example.icomplaint.model

import com.google.firebase.firestore.Exclude

open class CommentsId {
    @Exclude
    var ComentsId: String? = null
    fun <T : CommentsId?> withId(id: String): T {
        ComentsId = id
        return this as T
    }
}