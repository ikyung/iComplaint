package com.example.icomplaint


import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import com.canhub.cropper.CropImage
import com.canhub.cropper.CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE
import com.canhub.cropper.CropImageContract
import com.canhub.cropper.CropImageView
import com.canhub.cropper.options
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference

class AddPostActivity : AppCompatActivity() {
    private var mAddPostBtn: Button? = null
    private var mCaptionText: EditText? = null
    private var mPostImage: ImageView? = null
    private var mProgressBar: ProgressBar? = null
    private var postImageUri: Uri? = null
    private var storageReference: StorageReference? = null
    private var firestore: FirebaseFirestore? = null
    private var auth: FirebaseAuth? = null
    private var currentUserId: String? = null
    private var postToolbar: Toolbar? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_post)
        mAddPostBtn = findViewById(R.id.save_post_btn)
        mCaptionText = findViewById(R.id.caption_text)
        mPostImage = findViewById(R.id.post_image)
        mProgressBar = findViewById(R.id.post_progressBar)
        mProgressBar?.visibility = View.INVISIBLE
        postToolbar = findViewById(R.id.addpost_toolbar)
        setSupportActionBar(postToolbar)
        supportActionBar!!.title = "Add Complaint"
        storageReference = FirebaseStorage.getInstance().reference
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        currentUserId = auth!!.currentUser!!.uid

        val getContent = registerForActivityResult(CropImageContract()) { uri: CropImageView.CropResult? ->
            // Do something with the obtained Uri
            postImageUri = uri?.uriContent
            mPostImage?.setImageURI(postImageUri)
        }

        mPostImage?.setOnClickListener(View.OnClickListener {
            getContent.launch(

            options {
                setGuidelines(CropImageView.Guidelines.ON)
                setAspectRatio(3, 2)
                setMinCropResultSize(512, 512)

            }.apply {
                this@AddPostActivity
            })


        })
        mAddPostBtn?.setOnClickListener(View.OnClickListener {
            mProgressBar?.visibility = View.VISIBLE
            val caption = mCaptionText?.text.toString()
            if (caption.isNotEmpty() && postImageUri != null) {
                val postRef = storageReference!!.child("post_images")
                    .child(FieldValue.serverTimestamp().toString() + ".jpg")
                postRef.putFile(postImageUri!!).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        postRef.downloadUrl.addOnSuccessListener { uri ->
                            val postMap = HashMap<String, Any>()
                            postMap["image"] = uri.toString()
                            postMap["user"] = currentUserId!!
                            postMap["caption"] = caption
                            postMap["time"] =
                                FieldValue.serverTimestamp()
                            firestore!!.collection("Posts").add(postMap)
                                .addOnCompleteListener { task ->
                                    if (task.isSuccessful) {
                                        mProgressBar?.visibility = View.INVISIBLE
                                        Toast.makeText(
                                            this@AddPostActivity,
                                            "Post Added Successfully !!",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                        startActivity(
                                            Intent(this@AddPostActivity, MainActivity::class.java)
                                        )
                                        finish()
                                    } else {
                                        mProgressBar?.visibility = View.INVISIBLE
                                        Toast.makeText(
                                            this@AddPostActivity,
                                            task.exception.toString(),
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }
                        }
                    } else {
                        mProgressBar?.visibility = View.INVISIBLE
                        Toast.makeText(
                            this@AddPostActivity,
                            task.exception!!.message,
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            } else {
                mProgressBar?.visibility = View.INVISIBLE
                Toast.makeText(
                    this@AddPostActivity,
                    "Please Add Image and Write Your caption",
                    Toast.LENGTH_SHORT
                ).show()
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                postImageUri = data?.data
                mPostImage?.setImageURI(postImageUri)
            } else if (resultCode == CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                Toast.makeText(this, resultCode, Toast.LENGTH_SHORT).show()
            }
        }
    }
}