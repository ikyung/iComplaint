package com.example.icomplaint.adapter

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.icomplaint.CommentsActivity
import com.example.icomplaint.model.Post
import com.example.icomplaint.model.Users
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import de.hdodenhof.circleimageview.CircleImageView
import java.util.*

class PostAdapter(context: Activity, mList: List<Post>, usersList: MutableList<Users?>?) :
    RecyclerView.Adapter<PostAdapter.PostViewHolder>() {
    private var mList: MutableList<Post>
    private var usersList: MutableList<Users>
    private var context: Activity
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    init {
        this.mList = mList as MutableList<Post>
        this.context = context
        this.usersList = usersList as MutableList<Users>
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PostViewHolder {
        val v: View = LayoutInflater.from(parent.context).inflate(com.example.icomplaint.R.layout.each_post, parent, false)
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        return PostViewHolder(v)
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    override fun onBindViewHolder(holder: PostViewHolder, position: Int) {
        val post: Post = mList[position]
        holder.setPostPic(post.image)
        holder.setPostCaption(post.caption)
        val currentDate = Date()
        val dateFormat = android.text.format.DateFormat.getDateFormat(context)
        val dateString = dateFormat.format(currentDate)
        holder.setPostDate(dateString)

        val username: String? = usersList[position].name
        val image: String? = usersList[position].image
        holder.setProfilePic(image)
        holder.setPostUsername(username)


        //likebtn
        val postId: String? = post.PostId
        val currentUserId = auth.currentUser?.uid
        holder.likePic.setOnClickListener {
            if (currentUserId != null) {
                firestore.collection("Posts/$postId/Likes").document(currentUserId).get()
                    .addOnCompleteListener { task ->
                        if (!task.result.exists()) {
                            val likesMap: MutableMap<String, Any> =
                                HashMap()
                            likesMap["timestamp"] =
                                FieldValue.serverTimestamp()
                            firestore.collection("Posts/$postId/Likes").document(currentUserId)
                                .set(likesMap)
                        } else {
                            firestore.collection("Posts/$postId/Likes").document(currentUserId)
                                .delete()
                        }
                    }
            }
        }

        //like color change
        if (currentUserId != null) {
            firestore.collection("Posts/$postId/Likes").document(currentUserId)
                .addSnapshotListener { value, error ->
                    if (error == null) {
                        if (value!!.exists()) {
                            holder.likePic.setImageDrawable(context.getDrawable(com.example.icomplaint.R.drawable.after_liked))
                        } else {
                            holder.likePic.setImageDrawable(context.getDrawable(com.example.icomplaint.R.drawable.before_liked))
                        }
                    }
                }
        }

        //likes count
        firestore.collection("Posts/$postId/Likes").addSnapshotListener { value, error ->
            if (error == null) {
                if (!value!!.isEmpty) {
                    val count = value.size()
                    holder.setPostLikes(count)
                } else {
                    holder.setPostLikes(0)
                }
            }
        }

        //comments implementation
        holder.commentsPic.setOnClickListener {
            val commentIntent = Intent(context, CommentsActivity::class.java)
            commentIntent.putExtra("postid", postId)
            context.startActivity(commentIntent)
        }
        if (currentUserId == post.user) {
            holder.deleteBtn.visibility = View.VISIBLE
            holder.deleteBtn.isClickable = true
            holder.deleteBtn.setOnClickListener {
                val alert = AlertDialog.Builder(context)
                alert.setTitle("Delete")
                    .setMessage("Are You Sure ?")
                    .setNegativeButton("No", null)
                    .setPositiveButton(
                        "Yes"
                    ) { dialog, which ->
                        firestore.collection("Posts/$postId/Comments").get()
                            .addOnCompleteListener { task ->
                                for (snapshot in task.result) {
                                    firestore.collection("Posts/$postId/Comments")
                                        .document(snapshot.id).delete()
                                }
                            }
                        firestore.collection("Posts/$postId/Likes").get()
                            .addOnCompleteListener { task ->
                                for (snapshot in task.result) {
                                    firestore.collection("Posts/$postId/Likes")
                                        .document(snapshot.id).delete()
                                }
                            }
                        firestore.collection("Posts").document(postId.toString()).delete()
                        mList.removeAt(position)
                        notifyDataSetChanged()
                    }
                alert.show()
            }
        }
    }

    override fun getItemCount(): Int {
        return mList.size
    }

    inner class PostViewHolder(var mView: View) : RecyclerView.ViewHolder(
        mView
    ) {
        lateinit var postPic: ImageView
        lateinit var commentsPic: ImageView
        lateinit var likePic: ImageView
        lateinit var profilePic: CircleImageView
        lateinit var postUsername: TextView
        lateinit var postDate: TextView
        lateinit var postCaption: TextView
        lateinit var postLikes: TextView
        var deleteBtn: ImageButton

        init {
            likePic = mView.findViewById(com.example.icomplaint.R.id.like_btn)
            commentsPic = mView.findViewById(com.example.icomplaint.R.id.comments_post)
            deleteBtn = mView.findViewById(com.example.icomplaint.R.id.delete_btn)
        }

        fun setPostLikes(count: Int) {
            postLikes = mView.findViewById(com.example.icomplaint.R.id.like_count_tv)
            postLikes.text = "$count Likes"
        }

        fun setPostPic(urlPost: String?) {
            postPic = mView.findViewById(com.example.icomplaint.R.id.user_post)
            Glide.with(context).load(urlPost).into(postPic)
        }

        fun setProfilePic(urlProfile: String?) {
            profilePic = mView.findViewById(com.example.icomplaint.R.id.profile_pic)
            Glide.with(context).load(urlProfile).into(profilePic)
        }

        fun setPostUsername(username: String?) {
            postUsername = mView.findViewById(com.example.icomplaint.R.id.username_tv)
            postUsername.text = username
        }

        fun setPostDate(date: String) {
            postDate = mView.findViewById(com.example.icomplaint.R.id.date_tv)
            postDate.text = date
        }

        fun setPostCaption(caption: String?) {
            postCaption = mView.findViewById(com.example.icomplaint.R.id.caption_tv)
            postCaption.text = caption
        }
    }
}