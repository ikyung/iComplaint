package com.example.icomplaint

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.icomplaint.adapter.CommentsAdapter
import com.example.icomplaint.model.Comments
import com.example.icomplaint.model.Users
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class CommentsActivity : AppCompatActivity() {
    private var commentEdit: EditText? = null
    private var mAddCommentBtn: Button? = null
    private var mCommentRecyclerView: RecyclerView? = null
    private var firestore: FirebaseFirestore? = null
    private var post_id: String? = null
    private var currentUserId: String? = null
    private var auth: FirebaseAuth? = null
    private var adapter: CommentsAdapter? = null
    private var mList: MutableList<Comments>? = null
    private var usersList: MutableList<Users?>? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_comments)
        commentEdit = findViewById(R.id.comment_edittext)
        mAddCommentBtn = findViewById(R.id.add_comment)
        mCommentRecyclerView = findViewById(R.id.comment_recyclerView)
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        currentUserId = auth!!.currentUser!!.uid
        mList = ArrayList()
        usersList = ArrayList()
        adapter = CommentsAdapter(this@CommentsActivity, mList as ArrayList<Comments>, usersList)
        post_id = intent.getStringExtra("postid")
        mCommentRecyclerView?.setHasFixedSize(true)
        mCommentRecyclerView?.layoutManager = LinearLayoutManager(this)
        mCommentRecyclerView?.adapter = adapter
        firestore!!.collection("Posts/$post_id/Comments").addSnapshotListener(
            this@CommentsActivity
        ) { value, error ->
            for (documentChange in value!!.documentChanges) {
                if (documentChange.type == DocumentChange.Type.ADDED) {
                    val comments = documentChange.document.toObject(
                        Comments::class.java
                    ).withId<Comments>(documentChange.document.id)
                    val userId = documentChange.document.getString("user")
                    firestore!!.collection("Users").document(userId!!).get()
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                val users = task.result.toObject(Users::class.java)
                                usersList?.add(users)
                                mList?.add(comments)
                                adapter!!.notifyDataSetChanged()
                            } else {
                                Toast.makeText(
                                    this@CommentsActivity,
                                    task.exception!!.message,
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                } else {
                    adapter!!.notifyDataSetChanged()
                }
            }
        }
        mAddCommentBtn?.setOnClickListener(View.OnClickListener {
            val comment = commentEdit?.text.toString()
            if (!comment.isEmpty()) {
                val commentsMap: MutableMap<String, Any> = HashMap()
                commentsMap["comment"] = comment
                commentsMap["time"] = FieldValue.serverTimestamp()
                commentsMap["user"] = currentUserId!!
                firestore!!.collection("Posts/$post_id/Comments").add(commentsMap)
                    .addOnCompleteListener { task ->
                        if (task.isSuccessful) {
                            Toast.makeText(
                                this@CommentsActivity,
                                "Comment Added",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            Toast.makeText(
                                this@CommentsActivity,
                                task.exception!!.message,
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
            } else {
                Toast.makeText(this@CommentsActivity, "Please write Comment", Toast.LENGTH_SHORT)
                    .show()
            }
        })
    }
}