package com.example.icomplaint.model

import java.util.*

class Post : PostId() {
    val image: String? = null
    val user: String? = null
    val caption: String? = null
    val time: Date? = null
}